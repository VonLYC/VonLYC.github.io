# 1

本题是标准的TEA（难度低于XTEA和XXTEA），选手只需要打开IDA找到v = {0x284c2234, 0x3910c558}, k = "base64xorteaxtea"，再通过观察，对比程序内TEA和正常TEA逻辑相同，故写出解密脚本：

```
#include <iostream>
#include <stdint.h>
 
void decrypt(uint32_t* v, uint32_t* k) {
        uint32_t v0 = v[0], v1 = v[1];
        uint32_t delta = 0x9e3779b9;
        uint32_t sum = delta * 32;
        uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
 
        for (int i = 0; i < 32; i++) {
                v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3);
                v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1);
                sum -= delta;
        }
 
        v[0] = v0;
        v[1] = v1;
}
 
 
int main()
{
        uint32_t v[2]; uint32_t v2;
        v[0] = 0x284c2234;
        v[1] = 0x3910c558;
        decrypt(v, (uint32_t*)"base64xorteaxtea");
        printf("moectf{%x-", v[0]);
        printf("%x-", v[1] >> 16 );
        printf("%x-9c42-caf30620caaf}", v[1] & 0xffff);
        return 0;
}
```

 # 2

base64标准码表是 `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`，这里换成了 `WHydo3sThiS7ABLElO0k5trange+CZfVIGRvup81NKQbjmPzU4MDc9Y6q2XwFxJ/`.



如果 IDA 显示是十六进制数据，则可以在十六进制数据那按下 A，从而得到字符串

再根据提示，在函数名字上按下x键找到是哪个函数引用了这个函数



# 3

既然已经获取了密文和密钥，那么我们完全可以套用 RC4 的算法来解密。因为 RC4 是流密码，它的本质就是异或，而 `a ^ b = c`，`c ^ b = a`，由此可以直接把内置的密文作为输入，然后使用算法进行解密。

```c
#include <stdio.h>
#include <string.h>
 
unsigned char sbox[256] = {0};
const unsigned char* key = (const unsigned char*)"NewStar";
unsigned char data[22] = {-60, 96,  -81, -71, -29, -1,  46,  -101, -11,  16,  86,
                          81,  110, -18, 95,  125, 125, 110, 43,   -100, 117, -75};
 
void swap(unsigned char* a, unsigned char* b) {
    unsigned char tmp = *a;
    *a = *b;
    *b = tmp;
}
 
void init_sbox(const unsigned char key[]) {
    for (unsigned int i = 0; i < 256; i++) sbox[i] = i;
    unsigned int keyLen = strlen((const char*)key);
    unsigned char Ttable[256] = {0};
    for (int i = 0; i < 256; i++) Ttable[i] = key[i % keyLen];
    for (int j = 0, i = 0; i < 256; i++) {
        j = (j + sbox[i] + Ttable[i]) % 256;
        swap(&sbox[i], &sbox[j]);
    }
}
 
void RC4(unsigned char* data, unsigned int dataLen, const unsigned char key[]) {
    unsigned char k, i = 0, j = 0, t;
    init_sbox(key);
    for (unsigned int h = 0; h < dataLen; h++) {
        i = (i + 1) % 256;
        j = (j + sbox[i]) % 256;
        swap(&sbox[i], &sbox[j]);
        t = (sbox[i] + sbox[j]) % 256;
        k = sbox[t];
        data[h] ^= k;
    }
}
 
int main(void) {
    unsigned int dataLen = sizeof(data) / sizeof(data[0]);
    RC4(data, dataLen, key);
    for (unsigned int i = 0; i < dataLen; i++) {
        printf("%c", data[i]);
    }
    return 0;
}
```



# TEA

```c
#include <stdio.h>
#include <stdint.h>
 
// 解密函数
void decrypt (uint32_t* v, uint32_t* k) {
    uint32_t v0 = v[0], v1 = v[1], i;
    uint32_t delta = 2654435769;
    uint32_t sum = (32)*delta;
    uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
    for (i = 0; i < 32; i++) { // 解密时将加密算法的顺序倒过来，+= 变为 -=
        v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
        v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
        sum -= delta;
    }
    v[0] = v0; v[1] = v1; // 解密后再重新赋值
}
 
 
unsigned char keys[] = "WelcomeToNewStar";
unsigned char cipher[] = { 0x78,0x20,0xF7,0xB3,0xC5,0x42,0xCE,0xDA,0x85,0x59,0x21,0x1A,0x26,0x56,0x5A,0x59,0x29,0x02,0x0D,0xED,0x07,0xA8,0xB9,0xEE,0x36,0x59,0x11,0x87,0xFD,0x5C,0x23,0x24 };
int main()
{
    unsigned char a;
    uint32_t *v = (uint32_t*)cipher;
    uint32_t *k = (uint32_t*)keys;
    // v 为要加密的数据是 n 个 32 位无符号整数
    // k 为加密解密密钥，为 4 个 32 位无符号整数，即密钥长度为 128 位
 
    for (int i = 0; i < 8; i += 2)
    {
        decrypt(v + i, k);
        // printf("解密后的数据：%u %u\n", v[i], v[i+1]);
    }
 
    for (int i = 0; i < 32; i++) {
        printf("%c", cipher[i]);
    }
 
    return 0;
}
```



# inverse

```c
void flag_decryption()
{
        DWORD flag[12] = { 0xb5073388 , 0xf58ea46f , 0x8cd2d760 , 0x7fc56cda , 0x52bc07da , 0x29054b48 , 0x42d74750 , 0x11297e95 , 0x5cf2821b , 0x747970da , 0x64793c81, 0x00000000 };
        for (int i = 0; i < 11; i++)
        {
                *(flag + i) ^= 0xdeadbeef + 0xd3906;
                *(flag + i) -= 0xdeadc0de;
                *(flag + i) *= 2371998067; // 0xccffbbbb 的乘法逆元（在mod 0xffffffff+1下） Ref: https://zh.planetcalc.com/3311/
        }
 
        std::cout << (unsigned char*)flag << std::endl;
 
        // moectf{c5f44c32-cbb9-444e-aef4-c0fa7c7a6b7a}
}
```

